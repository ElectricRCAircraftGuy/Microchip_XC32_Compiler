/*
 *  Header for xc32 
 */

#ifndef _xc32_HEADER_DEF
#define _xc32_HEADER_DEF

tool_chain = "XC32"
tool_version = MCHP_VERSION 
resource_version = MCHP_RESOURCE
field_count = 4
field_sizes = {  32, 4, 4, 4 }
resource_info_start

#endif
