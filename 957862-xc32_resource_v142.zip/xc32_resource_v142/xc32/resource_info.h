#include "../generator/resource_types.h"
#include "xc32_flag_definitions.h"
#ifndef MCHP_DONT_DEFINE_RESOURCES
#include "../generator/resource.c"
#endif

